import Foundation
struct FLAC {
 struct Block { var type: UInt8; var data: Data }
 var blocks: [Block] = []; var audio: Data
 enum Failure: Error { case invalid, oversized, duplicateComments }
 init(_ data: Data) throws {
  let b = Array(data); guard b.count >= 42, Array(b.prefix(4)) == [102,76,97,67] else { throw Failure.invalid }; var p=4; var last=false
  while !last { guard p+4 <= b.count else { throw Failure.invalid }; last = b[p]&128 != 0; let t=b[p]&127; let n=Int(b[p+1])*65536+Int(b[p+2])*256+Int(b[p+3]); p+=4; guard p+n<=b.count,t != 127 else { throw Failure.invalid }; blocks.append(Block(type:t,data:Data(b[p..<p+n]))); p+=n }
  guard blocks.first?.type == 0, blocks.first?.data.count == 34, p<b.count else { throw Failure.invalid }; audio=Data(b[p...])
 }
 static func le(_ n:Int)->Data { Data((0..<4).map{UInt8(truncatingIfNeeded:n >> ($0*8))}) }
 static func be(_ n:Int)->Data { Data((0..<4).reversed().map{UInt8(truncatingIfNeeded:n >> ($0*8))}) }
 func comments() throws -> (Data,[Data]) {
  let c=blocks.filter{$0.type==4}; guard c.count<=1 else {throw Failure.duplicateComments}; guard let d=c.first?.data else {return (Data("FLAC Toolkit".utf8),[])}; let b=Array(d); var p=0
  func number() throws -> Int {guard p+4<=b.count else {throw Failure.invalid}; let n=(0..<4).reduce(0){$0 | Int(b[p+$1]) << ($1*8)}; p+=4; return n}
  func bytes() throws -> Data {let n=try number(); guard n<=b.count-p else {throw Failure.invalid}; defer{p+=n}; return Data(b[p..<p+n])}
  let vendor=try bytes(); let count=try number(); guard count <= (b.count-p)/4 else {throw Failure.invalid}; var entries=[Data](); for _ in 0..<count {entries.append(try bytes())}; guard p==b.count else {throw Failure.invalid}; return(vendor,entries)
 }
 mutating func edit(_ changes:[String:String]) throws {guard !changes.isEmpty else{return}; let (vendor,old)=try comments(); var entries=old.filter{d in guard let s=String(data:d,encoding:.utf8),let i=s.firstIndex(of:"=") else{return true}; return changes[String(s[..<i]).uppercased()]==nil}; for k in changes.keys.sorted(){if let v=changes[k], !v.isEmpty {entries.append(Data("\(k)=\(v)".utf8))}}; var d=Self.le(vendor.count)+vendor+Self.le(entries.count); for e in entries {d += Self.le(e.count)+e}; blocks.removeAll{$0.type==4}; blocks.insert(Block(type:4,data:d),at:1) }
 mutating func artwork(_ data:Data,mime:String,width:Int,height:Int,depth:Int) { let m=Data(mime.utf8); var d=Self.be(3)+Self.be(m.count)+m+Self.be(0); for n in [width,height,depth,0,data.count]{d += Self.be(n)}; d += data; blocks.removeAll{ $0.type==6 && $0.data.prefix(4)==Self.be(3) }; blocks.append(Block(type:6,data:d)) }
 func encoded() throws -> Data {var d=Data([102,76,97,67]); for (i,b) in blocks.enumerated(){let n=b.data.count; guard n<=0xffffff else{throw Failure.oversized}; d += Data([b.type | (i==blocks.count-1 ? 128:0),UInt8(n>>16),UInt8((n>>8)&255),UInt8(n&255)]); d += b.data}; d += audio; return d}
}
